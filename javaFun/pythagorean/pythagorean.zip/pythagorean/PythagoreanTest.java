public class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean NewVar = new Pythagorean();
        double hypotenusResult = NewVar.calcucateHypotenuse(12, 4);
        System.out.println(hypotenusResult);
    }
}