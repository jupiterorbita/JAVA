public class FirstJavaProgramm{
    public static void main(String[] args){
        System.out.println("My name is Coding Dojo");
        System.out.println("I am 9999 years old");
        System.out.println("I live here =) ");
    }
}